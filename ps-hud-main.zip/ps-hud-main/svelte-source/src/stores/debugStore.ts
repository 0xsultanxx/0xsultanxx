const debugMode: boolean = import.meta.env.DEV;
export default debugMode;